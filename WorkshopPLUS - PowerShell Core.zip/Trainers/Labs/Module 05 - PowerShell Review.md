<!--
WorkshopPLUS - PowerShell Core
Module 03: PowerShell Review
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: PowerShell review

#### Introduction  
This lab covers review topics within PowerShell. These topics cover not only the basics, but more advanced concepts within PowerShell.

#### Prerequisites (if applicable)   
Recommended: PowerShell for the IT Administrator Part 1 Premier course or equivalent knowledge.

#### Estimated Time to Complete This Lab  
45 minutes

### Task 1. PowerShell review: Get-Member 

1. Switch to the Ubuntu machine in the lab environment and enter the password **PowerShell6** to log onto the machine. 
   
2. Launch VSC.
   
3. Create a new file in VSC: Code.ps1. You can save this to any location on the computer.

4. Create a text file on the desktop named 'Audit.txt'.
```posh
sl /home/$env:USER/Desktop
New-Item -Name Audit.txt -ItemType File
```

5. Now obtain the member properties and methods of the created file. 
```posh
Get-Item -Name Audit.txt | Get-Member
```
6. Review the values you are allowed to 'Set'. Also review the values you are you only allowed to 'Get'.
   
7. Get the 'lastAccessTime' of the file.
```posh
$File = Get-Item Audit.txt
$file.LastAccessTime
```
      
8. Now set the 'lastAccessTime' of the file. 
```posh
$file.LastAccessTime = (get-date).AddYears(-200)
$file.LastAccessTime
```
9. What other values of 'LastAccessTime' can be set via Get-Date?
Hint: Run Get-Member on Get-Date

10. (Optional) What is the earliest date that a file property can be set to?

### Task 2. PowerShell review: Aliases

1. Review current alias within PowerShell. Still using the Ubuntu server and VSC.

2. List out all current Aliases.
```posh
get-alias
```
3. List alias in a format wide output. This won't show the name of the action per alias, but is an easy reference.
```posh
Get-Alias | fw -Column 4
```

4. Create a new alias in the current PowerShell session.
```posh
New-Alias -Name List -Value Get-ChildItem
```

5. Run the new alias 'List'. What is the result? 
   
6. You can also remove the alias from the current session.
```posh
Remove-Item alias:list
```

### Task 3. PowerShell review: Create a function with a computer parameter to restart a remote server.

1. Using the Win10 machine, logon as contoso\student and enter the password **PowerShell6**. Open Visual Studio, create a function with the following requirements:
    - Use cmdletbinding leveraging the should process
    - Set impact to 'medium'
    - parameter of computer(s) to input for restarting
    - Don't forget to add help content to your function. 

2. Start with creating a function, call it: Restart-SpecificComputer
```posh
Function Restart-SpecificComputer {}
```

3. Add cmdletbinding with the should process enabled: 
```posh
[CmdletBinding(SupportsShouldProcess=$true, 
                  ConfirmImpact='Medium')]
```

4. Use a parameter of $ComputerNeeded. No additional parameter parameters are needed for this task.
```posh
param($ComputerNeeded)
```
    
5.  The should process code in the process section looks something like this:
```posh
if ($pscmdlet.ShouldProcess("$ComputerNeeded", "is performing the action of restarting $ComputerNeeded"))
        {
            Restart-Computer $ComputerNeeded
        }
```
6. Run the function with the -whatif parameter. You can use a non-existent machine name for testing.
   
7. Confirm the Get-Help code is working as expected. 
```posh
Get-Help Restart-SpecificComputer -Full
```
   
8. Run the function with the -confirm parameter. Select 'No' to execute the code. 
   
9.  Lower the $ConfirmPreference value to 'low' and confirm the impact level works without the -whatif parameter. 
```posh
$ConfirmPreference = 'Low'
```
   
10. Reset the $ComfirmPreference value to 'high'.
```posh
$ConfirmPreference = 'High'
```
   
Sample completed code:
```posh
Function Restart-SpecificComputer {
<#
.Synopsis
   Restart specified computers.
.DESCRIPTION
   Function to restart a specific individual or list of computers. 
.EXAMPLE
   Restart-SpecificComputer -ComputerNeeded localhost
   This will restart the localhost.
.EXAMPLE
   Restart-SpecificComputer -ComputerNeeded RemotePC
   This will restart the 'RemotePC' computer. 
.NOTES
   Version 1.0
#>
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    Param ($ComputerNeeded)

    {
        if ($pscmdlet.ShouldProcess("$ComputerNeeded", "restarting computer"))
        {
                Restart-Computer $ComputerNeeded
        }
    }
}
```

### Task 4. PowerShell review: Using Begin, Process, and End blocks.

1. Using the Ubuntu client machine, open Visual Studio, create a function with the following requirements:
    - Use 'Begin, Process, and End' blocks
    - Use a parameter for path ($Path)
    - Present information to the end user that the collection of information has started.
    - At the conclusion of the function, present to the end user that the collection process has completed.
    - Set a parameter of path location.
  
2. Function can be named: Get-FolderInformation
```posh
Function Get-FolderInformation
```
3. In the 'Begin' block, 'Test-Path' to see if the $path value is valid. If not valid, then break out of the script and Write-Host to the end user the information.
```posh
If (Test-path $path) {
    Write-Host "Path exists, can continue with collection."}
Else {Write-Host "Path does not exist, ending function";break}
```
4. In the 'Process' block, perform the lookup with Get-ChildItem -Directory -recurse, supress any errors, and output to a file in a temp location:
```posh
Get-ChildItem $Path -Directory -Recurse -ErrorAction SilentlyContinue > "/tmp/directory.txt" 
```

Note: One inconsistency with PS and different platforms is the temp folder location. This is an Operating System inconsistency that PS has not provided a work around at this writing. 

- Windows: $env:TEMP
- macOS: $env:TMPDIR
- Linux:  /tmp
    
5. In the 'End' block, present that the collection process has completed. 
```posh
Write-Host "The function has completed."
```
   
Optional tasks:

6. Colorize the output for the end user to easily see the success or failure of the function.
   
7. Add Write-Verbose statements to help troubleshoot when the code is executing. This allows information to be presented when not in debug mode. (Hint: This would also require cmdletbinding to be added to the function.)


### Task 5. PowerShell review: Create a workflow (Optional)
                  
                  


   
