<!--
WorkshopPLUS - PowerShell Core
Module 03: Visual Studio Code - coding
-->
## Exercise 1: Install Visual Studio Code on Windows 10

#### Introduction  
This lab details the process to install and configure Visual Studio Code on Windows 10

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
45 minutes

### Task 1. Install Visual Studio Code on Windows 10

1. Switch to the Windows 10 machine in the lab environment and enter the password **PowerShell6** to log in to the machine. 

2. Open a browser and navigate to https://code.visualstudio.com/

3. Click on the Download button.