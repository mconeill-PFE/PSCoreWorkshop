<!--
WorkshopPLUS - PowerShell Core
Module 04: Visual Studio Code
-->

## Exercise 1: Install Visual Studio Code Live Share

#### Introduction  
This lab details the process to configuring and launching Visual Studio Code Live Share process. In this lab exercise, you'll need to work with another attendee within the workshop. You'll need to know an e-mail address to send and receive the URL live share information between you and your co-worker. 

#### Prerequisites
E-mail information from another attendee within the workshop.   

#### Estimated Time to Complete This Lab  
30 minutes

### Task 1. Setup VSC Live Share on one of the client machines, either the WinClient or Ubuntu client machine.
### Task 1a. Setup VSC Live Share on WinClient client machine.
1. Log onto the WinClient machine.

2. Download and isntall VSC Live Share extension pack.  

3. Open a browser and navigate to https://marketplace.visualstudio.com/items?itemName=MS-vsliveshare.vsliveshare-pack

4. Click on the Install button.

6. Wait for the extension to finish downloading and then reload VS Code when prompted.

6. Wait for Visual Studio Live Share to finish installing dependencies (you'll see progress updates in the status bar).
   
7. Restart VS Code when done.

8. Once complete, you'll see a Share appear in your status bar. You can now begin collaborating with others immediately.

![](Media/module4/1-aaa.png)
### Task 1b. Setup VSC Live Share on the Ubuntu client machine.
1. Log onto the Ubuntu client machine.
    
2. If you'd prefer not to run an automated script, you may install the libraries manually by navigating to: https://docs.microsoft.com/en-us/visualstudio/liveshare/reference/linux#details-on-required-libraries
    
3. To auto-install, click Install in the notification.
    
4. A terminal window will appear and run a script. Your OS will ask you to enter your admin (sudo) password for the run package install commands. 
    
5. Restart VSC when done.

### Task 2. Setup sharing access on client machine. 

1. Using either client machine, click the Share button in your status bar, which will share your project, and copy a unique session URL to your clipboard.

![](Media/module4/1-aaa.png)

2. You'll be asked to sign in the first time you share (using a GitHub or Microsoft account), which allows others to identity you when collaborating. Click the Launch Sign In button, complete the authentication process in your browser, and then return to VS Code.

![](Media/module4/2-aaa.png)

Note: On Windows, you may be asked to allow Live Share to open a firewall port, in order to enable peer-to-peer connections.

3. Send the session URL to another student in the workshop. The URL is copied to your clipboard. It'll be best to copy/paste the value into an e-mail and send it to yourself.
Note: The machines have internet access, however, you cannot copy out of the virtual machines. Therefore, it's best to send yourself an e-mail, using a browser on one client machine, then opening the e-mail on the other client machine. 

![](Media/module4/3-aaa.png)

4. Once you accep

![](Media/module4/4-aaa.png)

### Task 3. Joining a Live Share session. 

1. Click the session URL that the "host" sent you, which will open it up in a browser.
   
2. When prompted, allow your browser to launch VS Code.
   
3. You'll be asked to sign in the first time you share (using a GitHub or Microsoft account), which allows others to identity you when collaborating. Click the Launch Sign In button, complete the authentication process in your browser, and then return to VS Code.

![](Media/module4/2-aaa.png)

4. After you join, you'll be immediately presented with the file that the "host" has open, and can see their cursor and any edits they make.

### Task 4. Collaborating within a Live Share session. 

1. Once you and your guest are in a live share session, move the mouse around, edit, and hightlight text. Have the guest perform the same tasks and watch the actions perform live.

### Task 5. Co-Debugging within a Live Share session. 

1. VS Live Share allows you to co-debug files. Using the 'debug' menu, has the most common debug commands:
![](Media/module4/7-aaa.png)

2. However, you can also edit VS Code user settings. To create a launch.json file, open your project folder in VS Code (File > Open Folder) and then click on the Configure gear icon on the Debug view top bar.

![](Media/module4/8-aaa.png)

3. VS Code will try to automatically detect your debug environment but if this fails, you will have to choose your debug environment manually:

![](Media/module4/9-aaa.png)

4. Confirm the launch configuration generated for Node.js debugging matches:
```posh
{
    "version": "0.2.0",
    "configurations": [
        {
            "type": "node",
            "request": "launch",
            "name": "Launch Program",
            "program": "${file}"
        }
    ]
}
```

5. Go back to the File Explorer view (Ctrl+Shift+E), you'll see that VS Code has created a .vscode folder and added the launch.json file to your workspace.

![](Media/module4/10-aaa.png)

> [!hint] Note: You can debug a simple application even if you don't have a folder open in VS Code but it is not possible to manage launch configurations and set up advanced debugging. The VS Code Status Bar is purple if you do not have a folder open.

Also, attributes available in launch configurations vary from debugger to debugger. You can use IntelliSense suggestions (Ctrl+Space) to find out which attributes exist for a specific debugger. In addition, hover help is available for all attributes.

Furthermore, do not assume that an attribute that is available for one debugger automatically works for other debuggers too. If you see green squiggles in your launch configuration, hover over them to learn what the problem is and try to fix them before launching a debug session.

![](Media/module4/11-aaa.png)

6. Open a file in your hosting session. 
7. Luanch the debugger, F5 and start a debug session.
8. Have the guest set break points by clicking to the left of the numbers. A red dot signifies that a break point is set. 

### Task X. (Optional) Collaborating with multiple users at the same time in a Live Share session. 

1. Identify one primary attendee as the primary sharing session. 
2. Send the sharing URL to multiple recipients.
3. Once others have joined, repeat tasks 4-5 and allow different users control the session. 
