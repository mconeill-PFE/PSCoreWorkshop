<!--
WorkshopPLUS - PowerShell Core
Module 08: DSC
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Windows PowerShell DSC - Windows Web Server Configuration

#### Introduction  
In this exercise you will design and push a configuration to a Windows Server machine.

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1: Download Pre-Requisite Modules

1. Switch to the Windows 10 Machine and open Windows PowerShell as an administrator.

2. You need to install some DSC resources from the PowerShell gallery to assist with configuring the server. Type the code below at the prompt and press **Enter**.
```
# If you are prompted to install the Nuget package provider enter Y when prompted
Install-Module ComputerManagementDSC -Force
```
3. Open Visual Studio Code and click on Open Folder.

![](Media/Module06/6-aaa.png)

4. Create a new folder called WebConfiguration, highlight it and click **Select Folder**

![](Media/Module06/6-bbb.png)

5. Create a new file and call it WindowsWebConfig.ps1.

6. Enter the code below as the base code block for the configuration. 

```
Configuration WindowsWebConfig {

    Node $ComputerName {
        
    }

}
```
7. First we have will need some parameters as input for the configuration. Enter the code below under the Configuration line in the script.
```
Param($DomainJoinCredential,$ComputerName)
```
8. Under that line add the code to import the DSC resources. This will tell the configuration which resources are required.
```
Import-DscResource -ModuleName ComputerManagementDSC,PSDesiredStateConfiguration
```
9. Now we can join the machine to the domain. In the node block enter the code below to join the machine to our domain.
```
Computer DomainJoin {
            Name = $ComputerName
            DomainName = 'contoso.com'
            Credential = $DomainJoinCredential
        }
```
10. DSC will automatically reboot the server after this is complete. We can now install the web server role and ensure that it is dependant on the computer joining the domain. Enter the code below under the Computer resource block in the configuration.
```
WindowsFeature WebServer {
            Ensure = "Present"
            Name = "Web-Server"
            DependsOn = '[Computer]DomainJoin'
        }
```
11. Finally we will copy the file(s) for the website to the correct directory we will create a share to act as a source for these.

```
File WebSiteFiles {
            Ensure = "Present"
            DestinationPath = "C:\inetpub\wwwroot"
            SourcePath = "C:\Temp\index.html"
            DependsOn = '[WindowsFeature]WebServer'
        }
```
12. Now that we have a configuration it needs to be compiled into a mof file. As credential encryption and certificates are outside the scope of this we will tell DSC to use plain text passwords in the configuration. For a production configuration this should never be done. We need to specify a configuration data block to do this. Enter the code below into the script - below the Configuration script block.

```
$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName = "*"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        },
        @{
            NodeName = "WEB01"
        }
    )
}
```
13. Add the following lines to the script to prompt for a credential and then generate the configuration mof file.
```
$Credential = Get-Credential
WindowsWebConfig -ComputerName WEB01 -DomainJoinCredential $Credential -ConfigurationData $ConfigurationData
```
14. Press **F5** to run the configuration - enter the contoso\student username and password when prompted. A mof file will be generated which we can push to the machine.
```
PS C:\Users\student.CONTOSO\Documents\WebConfiguration> c:\Users\student.CONTOSO\Documents\WebConfiguration\WindowsWebConfig.ps1


cmdlet Get-Credential at command pipeline position 1
Supply values for the following parameters:
User: contoso\student
Password for user contoso\student: ************


    Directory: C:\Users\student.CONTOSO\Documents\WebConfiguration\WindowsWebConfig


Mode                LastWriteTime         Length Name
----                -------------         ------ ----
-a----        7/30/2018  12:06 AM           4184 WEB01.mof
```

### Task 2: Apply the Confiuration

1. We can now apply the configuration to the Windows server. Before that we need to distrubute the DSC resource to the machine as we are using a push configuration. In order to connect to the web server which is untrusted we must add its IP address to the trusted hosts setting for PowerShell WinRM. Type the code below into a Windows PowerShell console which is running as an administrator.
```
Set-Item WSMan:\localhost\Client\TrustedHosts -Value 10.0.1.7 -Force
```
2. In the Visual Studio Code terminal we can create a remote session to this machine as below.
```
$Credential = Get-Credential -Username Student
$session = New-PSSession -ComputerName 10.0.1.7 -Credential $Credential
```
3. Copy the DSC resource to the new web server box by using the code below. 
```
Copy-Item 'C:\Program Files\WindowsPowerShell\Modules\ComputerManagementDsc' -Destination "C:\Program Files\WindowsPowerShell\Modules\" -Recurse -Force -ToSession $session -Verbose
```
4. Copy the website files to the remote machine in a temp directory
```
Invoke-Command -Session $session -ScriptBlock {New-Item C:\Temp -ItemType Directory}
Copy-Item 'C:\Temp\index.html' -Destination C:\Temp\index.html -Force -ToSession $Session -Verbose
```
5. We also need to tell the machine to reboot if required. In a new script type the script below and press **F5** to generate a meta configuration for the server.
```
[DscLocalConfigurationManager()]
Configuration LCMSetting {
    Param($ComputerName)
    Node $ComputerName {
        Settings {
            RebootNodeIfNeeded = $true
        }
    }
}

LCMSetting -ComputerName 10.0.1.7
```
6. You should get output similar to the below.
```
Directory: C:\Users\student.CONTOSO\Documents\WebConfiguration\LCMSetting


Mode                LastWriteTime         Length Name
----                -------------         ------ ----
-a----        7/30/2018  12:31 AM           1072 10.0.1.7.meta.mof
```
7. Create a remote CIM session to the machine and apply the Local Configuration Manager settings.
```
$CIMSession = New-CIMSession -ComputerName 10.0.1.7
Set-DscLocalConfigurationManager -Path .\LCMSetting -CimSession $CIMSession -Verbose
```
8. Finally we can apply the configuration - monitor the verbose output.
```
Rename-Item '.\WindowsWebConfig\WEB01.mof' '10.0.1.7.mof'
Start-DscConfiguration -Path .\WindowsWebConfig -CimSession $CIMSession -Verbose -Wait
```
NOTE: When you run this you should see the machine join to the domain. Your connection to the remote machine will be severed once it reboots and an error will be displayed. The configuration will continue in the backgroup and takes around 5 minutes.

9. Test that the web server is active by browsing to http://10.0.1.7 .

![](Media/Module06/6-ccc.png)


## Exercise 1: Windows PowerShell DSC - Ubuntu Web Server Configuration

#### Introduction  
In this exercise you will configure the Ubuntu server to act as a web server using the DSC agent for Linux.

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1: Install the DSC Agent

1. Switch to the Ubuntu server and login using the student username and password. 

2. Run the code below to install the OMI server and DSC package.
```
wget https://github.com/Microsoft/omi/releases/download/v1.1.0-0/omi-1.1.0.ssl_100.x64.deb
wget https://github.com/Microsoft/PowerShell-DSC-for-Linux/releases/download/v1.1.1-294/dsc-1.1.1-294.ssl_100.x64.deb

sudo dpkg -i omi-1.1.0.ssl_100.x64.deb dsc-1.1.1-294.ssl_100.x64.deb
```
### Task 2: Create the Configuration

1. Switch to the Windows 10 machine and open the previous workspace you created for the Windows server in Visual Studio Code. 

2. Create a new script called LinuxWebConfig.ps1

3. Enter the code below as the base code block for the configuration. 

```
Configuration LinuxWebConfig {

    Node $ComputerName {
        
    }

}
```
4. Open a Windows PowerShell terminal as an adminstrator and use the code below to install the Linux DSC resources.
```
Install-Module nx -Force
```
5. In the script - add the lines below under the Configuration keyword to add a parameter for the computername and to improt the DSC resources.
```
Param($ComputerName)
    Import-DSCResource -ModuleName PSDesiredStateConfiguration,nx
```
6. Add a block into the Node scriptblock to install the Apache web server.
```
nxPackage Apache {
            PackageManager = 'Apt'
            Ensure = 'Present'
            Name = 'apache2'
        }
```
7. Copy the website files to the proper directory
```
nxFile webfiles {
            SourcePath = "/tmp/index.html"
            DestinationPath = "/var/www/html"
            Ensure = 'Present'
            Force = $true
            DependsOn = '[nxPackage]Apache'
        }
```
8. Add the line below to generate the configuration and press **F5** to create the mof file.
```
LinuxWebConfig -ComputerName 10.0.1.6
```
9. If successful you now have a mof file generated. 
```
Directory: C:\Users\student.CONTOSO\Documents\WebConfiguration\LinuxWebConfig


Mode                LastWriteTime         Length Name
----                -------------         ------ ----
-a----        7/30/2018   1:49 AM           2898 10.0.1.6.mof
```

### Task 2: Apply the Configuration

1. First we need to stage the website files on the Ubuntu server so the site can copy them. In the Visual Studio Code terminal run the following command to copy the file to the Ubuntu server.
```
scp C:\Temp\index.html student@10.0.1.6:/tmp/index.html
```
2. Create CIM session to the remote machine - note that DSC on Linux is only over SSL so we have to tell the CimSession to -UseSSL. As the Windows machine does not trust the certificate on the Ubuntu server we will set some options to remove the checking. This should not be done in production.
```
$Node = "10.0.1.6"
$Credential = Get-Credential -UserName:"root" -Message:"Enter Password:"
$opt = New-CimSessionOption -UseSsl:$true -SkipCACheck:$true -SkipCNCheck:$true -SkipRevocationCheck:$true
$Session = New-CimSession -Credential:$credential -ComputerName:$Node -Port:5986 -Authentication:basic -SessionOption:$opt -OperationTimeoutSec:90
```
3. You can verify that the session has been created by examining the **$Session** variable.
```
Id           : 3
Name         : CimSession3
InstanceId   : 1f40954e-a4ce-4942-bc80-631d693269b9
ComputerName : 10.0.1.6
Protocol     : WSMAN
```
4. Push the configuration to the node using the code below.
```
Start-DscConfiguration -Path .\LinuxWebConfig  -CimSession $session  -Wait -Verbose
```
5. Test that the configuration was applied successfully by browsing to http://10.0.1.6





