<!--
WorkshopPLUS - PowerShell Core
Module 06: PS Differences
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Text Manipulation

#### Introduction  
Use Linux commands and powershell equivalents

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

## Exercise 2: PowerShell Objects

#### Introduction  
PowerShell Objects and Linux

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

## Exercise 3: File Paths

#### Introduction  
Linux file paths and PowerShell Core

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

## Exercise 4: File Editing on Linux

#### Introduction  
File editing

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes