<!--
WorkshopPLUS - PowerShell Core
Module 02: Visual Studio Code
-->
#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used, the instruction will state **Windows Powershell**.

## Exercise 1: Install Visual Studio Code on Windows 10

#### Introduction  
This lab details the process to install and configure Visual Studio Code on Windows 10

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
45 minutes

### Task 1. Install Visual Studio Code on Windows 10

1. Switch to the Windows 10 machine in the lab environment and enter the password **PowerShell6** to log in to the machine. 

2. Open a browser and navigate to https://code.visualstudio.com/

3. Click on the Download button.

![](Media/Module02/2-aaa.png)

4. Click on the Windows button in the webpage.

![](Media/Module02/2-bbb.png)

5. When the download begins click on Run.
   
6. Click on **Next**
   
![](Media/Module02/2-ccc.png)

7. Select the radio button to accept the license agreement and click **Next**

![](Media/Module02/2-ddd.png)

8. Click **Next** to accept the default path.

![](Media/Module02/2-eee.png)

9. Click on **Next** to create a Start Menu folder.

![](Media/Module02/2-fff.png)

10. Check the boxes in the image as below to add "Open with Code" to explorer menus. Click **Next**

![](Media/Module02/2-ggg.png)

11. If all the options look correct then click **Install**.
    
![](Media/Module02/2-hhh.png)

12. Wait for Visual Studio Code to install - it can take a couple of minutes.
    
![](Media/Module02/2-iii.png)

13. When complete click on **Finish** to launch VS Code. 

![](Media/Module02/2-jjj.png)

### Task 2. Install the PowerShell extension

1. When first installed VS Code contains no extensions. Click on the extension icon.
   
![](Media/Module02/2-kkk.png)

2. In the search box type in *powershell*

3. Select the first entry in the list and click on Install. You can review the extension details in the main window.

![](Media/Module02/2-lll.png)

4. When complete - click on **Reload** to reload the workspace with the extension enabled. You only have to perform this action when you have a workspace open and install a new extension.

![](Media/Module02/2-mmm.png)

### Task 3. Use a Script to Install Visual Studio Code

1. This section is optional - but you can use a script to install Visual Studio Code and the PowerShell extension. First uninstall Visual Studio Code by clicking on Start -> Settings -> System -> Apps and Features
   
2. Select Microsoft Visual Studio Code and click **Uninstall**
   
3. Click on **Uninstall**

4. Click on **Yes**

5. Launch PowerShell Core and enter the code below. Press **Enter**
```
iex (iwr https://git.io/vbxjj)
```
6. Open Visual Studio Code and verify the PowerShell extension is installed.

### Task 4. Install Extensions

1. You can install any extension in the same way the PowerShell extension was installed. Search for and install the following list of extensions:
    - Markdown PDF
    - VS Live Share

## Exercise 2: Visual Studio Code Basics

### Task 1. Open a WorkSpace

1. VS Code uses the concept of workspaces for you to write code in. This helps to keep related scripts together and provides a boundary for source control. Click on the Explorer menu in VS Code. (CTRL+Shift+E)

![](Media/Module02/2-1-1.png)

2. Click on **Open Folder**. 

3. Use the file explorer and navigate to C:\Labs\Module2\. Select the Demo Scripts folder. Click **Select Folder**.

4. The Demo Scripts folder is now set as the workspace. Create a new PowerShell script by clicking on the New File icon (Or shortcut (CTRL+N) or File/New File) and entering a name for your script - with a ps1 extension. 

![](Media/Module02/2-1-2.png)

5. When you press enter you should see the icon next to the filename change to a PowerShell icon indicating that VS Code recognises the file as a PowerShell script file. 

### Task 2. Running Scripts

1. Click on the DemoScript.ps1 file in the explorer window.

2. Try adding some extra lines to the bottom of the script - see how VS Code uses Intellisense to suggest cmdlets and parameters. Try this for a few different commands. Examples: Get-Service, Get-Alias. 

3. To run just a selection of code, hightlight the code, by mouse selection, and then hit **F8** or **right-click** the selected code and choose **Run Selection**.

4. Note that in the pasted code the section "$process -ne $null" is underlined in green. VS Code incorporates the PSScriptAnalyzer which suggests possible best practice code violations. Also, 'Measure' is  underlined in Green. Alias are not recommended in coding. 
   
5. You can hover over the highlighted text or click on the **Problems** tab (mid screen) or **View -> Problems** menu, or (CTRL+SHIFT+M) to see the violated rule(s).
   
6. Change the line to match the below and the error will be cleared.
```
if ($null -ne $process) {
```
7. There are some other problems that the analyzer has detected - find and fix them. When hovering over a flagged problem, a lightbulb appears. ![](Media/Module02/2-2-3.png) Click on the lightbulb to see the suggestion to implement the change. Implement the recommendatoin by clicking on the suggestion. 

### Task 3. Running Scripts

1. To run a script there are a few options. Press **F5** to execute the script.

2. Click on the **Debug** menu on the left.

![](Media/Module02/2-3-2.png)
   
3. Click on the **Play** button and watch the script run, or **F5** that starts the debugger

![](Media/Module02/2-3-3.png)

4. When the file runs, another menu appears:

![](Media/Module02/2-3-4.png)

This menu allows additional navication while the file executes and/or while in Debug mode. 

### Task 4. Common Features and Tasks

Work through the examples below for some of the editing features in VS Code

1. Change all occurences
   - In the script you have written - highlight the letters VS and right click. Select **Change all occurences**. You can now edit all occurences at the same time. Change the text to Visual Studio.
  
2. Find and Replace
    - Highlight **Visual Studio** in the script and press Ctrl-H - replace all instances of this with VS again. 

3. Snippets
    - Type the word function and press **TAB** twice to insert a snippet for a function definition.
    - Add a function name and line of code to prevent any analyzer errors
  ```
    function Write-Input {
    param (
        [string]$InputText
    )
    Write-Output -InputObject $InputText
}
  ```
4. References and Definitions
    - Add a line of code down the bottom of the script which calls your function.
    - Right click on the function name in the line and select **Peek Definition**
    - Where the function is defined - the number of references should be 1 now. Click on the reference to see where the function is called. 
    - Try adding another file in the same directory and call your function in there. The number of references should increase.
    - Highlight a variable (such as $InputText) and right click and select **Find All References**. This works across files as well.

5. Interactive Playground
    - Open a new instance of Visual Studio Code
    - In the Welcome file - click on the Interactive Playground to view some more features.

![](Media/Module02/2-bba.png)

<!--
TODO: Add more features in here
-->

### Task 5. Debugging

1. Open the script *BreakPointTest.ps1*

2. Add some breakpoints to the script by clicking in the left margin beside each line that has a comment like the below. A red dot will appear.
   
```
<# Put a breakpoint here#>
```
![](Media/Module02/2-bca.png)

3. In the debug menu press the **Play** button or press **F5**.

4. The script will pause at the breakpoint and enter the debugging environment.

5. Drill down through the variables section and note how the automatic and script variables are initialized in each of the scopes. You can view proerties of all variables as you step through the script. 

6. Highlight a variable in your script and click **Debug: Add To Watch** . The variable is now tracked in the debugger and updated as you step through the script and its value changes.

7. Press F11 and step through the script.
    - Observe how the watch variable is updated
    - Follow how the script steps into the function and the variables window is updated with the function scope. 

### Task 6. Common Settings

1. Setting up user settings to optimze VSC options to optimize the user experience. 
   
2. Launch VSC on the Win10 machine.
   
3. 

<!--
TODO: Add more features in here
-->

### Task 7. Other File Formats

<!--
TODO: Maybe JSON, open a CSV and show how it suggests extensions?
-->

### Task 8. Pester Tests

1. Open the script BasicTest.Tests.ps1

2. This script contains Pester Unit tests. While the writing of the tests is beyond the scope of this course - we can view how these are detected by Visual Studio Code.

3. Click on **Run Tests** above the Describe block and see the output from Pester below. 



