<!--
WorkshopPLUS - PowerShell Core
Module 07: Remoting
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Windows PowerShell Remoting

#### Introduction  
In this exercise we will use Windows PowerShell to create a remote connection from Windows 10 to the domain controller. 

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
10 minutes

### Task 1: Windows PowerShell Remoting

1. Switch to the Windows 10 machine in the lab environment and enter the password **PowerShell6** to log in to the machine. 

2. Launch a Windows PowerShell session.

3. Enter the code below to create a session to the domain controller

```
$Credential = Get-Credential #Enter contoso\student and the password when prompted
Enter-PSSession -ComputerName WINDC -Credential $Credential
```
4. Confirm that the connection was successful by noting how the prompt has changed to [**WINDC**].
```
PS C:\Users\student.CONTOSO> $Credential = Get-Credential #Enter contoso\student and the password when prompted

cmdlet Get-Credential at command pipeline position 1
Supply values for the following parameters:
Credential
PS C:\Users\student.CONTOSO> Enter-PSSession -ComputerName WINDC -Credential $Credential
[WINDC]: PS C:\Users\student\Documents>
```
5. Type the code below to exit the session. 
```
Exit-PSSession
```

## Exercise 2: PowerShell Core Remoting - Windows

#### Introduction  
This time you will use PowerShell Core to connect from Windows 10 to the domain controller. 

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
10 minutes

### Task 1:

1. Launch PowerShell Core as an administrator from the Start menu.

2. An endpoint needs to be registered before PowerShell Core can be used for remoting. As the Enable-PSRemoting cmdlet is not yet implemented for PowerShell Core - a script must be executed to install the binaries and register the WinRM plugin.

3. Change to the PowerShell Core directory if you are not there already.
```
cd '.\Program Files\powershell\6'
```
4. Run the **Install-PowerShellRemoting.ps1** script.
```
.\Install-PowerShellRemoting.ps1
```
**NOTE** If this command generates an error run the code below
```
.\Install-PowerShellRemoting.ps1 -PowerShellHome (Get-Location)
```

5. Run the code below to confirm that the new endpoint exists.
```
Get-PSSessionConfiguration | Select Name
```
Result
```
PS C:\Program Files\PowerShell\6> Get-PSSessionConfiguration | Select Name

Name
----
PowerShell.6
PowerShell.6.1.0
```
6. To connect to the PowerShell Core endpoint we must specify its name when connecting. Use the code below to connect to the domain controller
```
$Credential = Get-Credential # Enter contoso\student and the password
Enter-PSSession -ComputerName WINDC -ConfigurationName PowerShell.6 -Credential $Credential
```
7. Query the $PSVersionTable and confirm you are connected to a PowerShell Core endpoint.
```
[WINDC]: PS C:\Users\student\Documents> $PSVersionTable

Name                           Value
----                           -----
PSVersion                      6.1.0
PSEdition                      Core
GitCommitId                    v6.1.0
OS                             Microsoft Windows 10.0.14393
Platform                       Win32NT
PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0...}
PSRemotingProtocolVersion      2.3
SerializationVersion           1.1.0.1
WSManStackVersion              3.0
```

## Exercise 3: PowerShell Core Remoting - Linux

#### Introduction  
In this module we will configure Linux to accept incoming communications from Windows and also Windows to accept incoming connections from Linux. 

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1: OpenSSH Setup

1. Open PowerShell Core as an administrator and run the code below to download, install and configure the sshd service.
```
Set-Location C:\Temp
Expand-Archive -Path C:\Temp\OpenSSH-Win64.zip -DestinationPath C:\Temp -Force
Copy-Item -Path .\OpenSSH-Win64\ -Destination 'C:\Program Files\OpenSSH\' -Force -Recurse
& "C:\Program Files\OpenSSH\install-sshd.ps1"
New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22
Start-Service -Name sshd
```
2. This code copies the Open SSH binaries and uses a PowerShell script to install them. A firewall rule is created to allow incoming connections on port 22.

3. SSH uses a configuration file to control the service - we must make the following changes to this file
- Allow password authentication
- Enter a subsystem value to launch PowerShell
First we can copy the default sshd config file.
```
Set-Location 'C:\Program Files\OpenSSH'
Copy-Item .\sshd_config_default .\sshd_config
```
4. Open the sshd_config file and remove the hash symbol from PasswordAuthentication as below

```
PasswordAuthentication yes
```
5. There is a bug with the sshd config file so we must use a symbolic link to overcome the space in C:\Program Files. Run the following code to create the link.
```
New-Item -ItemType SymbolicLink -Path C:\pwsh -Value "C:\Program Files\PowerShell\6" -Force
```
6. Add the line below to the sshd_config file and save and close it.
```
Subsystem    powershell c:\pwsh\pwsh.exe -sshs -NoLogo -NoProfile
```
7. Restart the sshd service
```
Copy-Item .\sshd_config $env:ProgramData\ssh\sshd_config
Restart-Service sshd
```
8. Add the OpenSSH location to the PATH variable so that it can find ssh.exe.
```
$oldPath = (Get-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name PATH).path
$newPath = "$oldPath;C:\Program Files\OpenSSH"
Set-ItemProperty -Path 'Registry::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Session Manager\Environment' -Name PATH -Value $newPath
```
### Task 2: SSHD Config on Ubuntu

1. Switch to the Ubuntu machine and log in.

2. Run the following block of code to enable remoting.
```
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
sudo curl -o /etc/apt/sources.list.d/microsoft.list https://packages.microsoft.com/config/ubuntu/16.04/prod.list
sudo wget http://security.ubuntu.com/ubuntu/pool/main/i/icu/libicu55_55.1-7ubuntu0.4_amd64.deb
sudo apt install ./libicu55_55.1-7ubuntu0.4_amd64.deb
sudo apt-get update
sudo apt-get install -y powershell
sudo cp -f /etc/ssh/sshd_config /etc/ssh/sshd_config_orig
sudo wget https://pscloudshellbuild.blob.core.windows.net/tools/sshd_config
sudo cp -f ./sshd_config /etc/ssh/sshd_config
sudo sed -i 's/pwsh-preview/pwsh/g' /etc/ssh/sshd_config
sudo service sshd restart
```

### Task 3: Verify Remote Connection

1. Switch to the Windows 10 machine.

2. Enter the code below and press **Enter**. Input your password when prompted
```
Enter-PSSession -HostName 10.0.1.6 -UserName student -SSHTransport
```
3. If the connection is successful the prompt with change to something like below. You can now use ordinary PowerShell commands on the Ubuntu server.
```
[ipaddress] /home/student
```
4. Switch to the Ubuntu machine

5. Enter the code below and press **Enter**. Input your password when prompted

<!-- Haven't finished this one yet>

