<!--
WorkshopPLUS - PowerShell Core
Module 01: Introduction
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Install PowerShell Core 

#### Introduction  
This lab shows you the process for manual and scripted installations of PowerShell Core on multiple operating systems.

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1. Install PowerShell Core on Windows 10

1. Switch to the Windows 10 machine in the lab environment and enter the password **PowerShell6** to log on to the machine. 

2. Open a browser and enter the address https://github.com/PowerShell/PowerShell/releases/download/v6.1.0/PowerShell-6.1.0-win-x64.msi in the taskbar.

3. Save the file to C:\Temp

4. Navigate to C:\Temp using file explorer and double click on **PowerShell-6.1.0-win-x64.msi** to run it.

![](Media/Module01/1-aaa.png)

5. Click on **Next**

![](Media/Module01/1-bbb.png)

6. Click the checkox to accept the end user license agreement and click **Next**.

![](Media/Module01/1-ccc.png)

7. Leave the installation path as it is and click **Next**.

![](Media/Module01/1-ddd.png)

8. Click **Install** to begin the installation. You may have to click **Yes** if prompted by User Account Control.

![](Media/Module01/1-eee.png)

9. The installation should proceed without any issues.

![](Media/Module01/1-fff.png)

10. When complete select the checkbox to **Launch PowerShell** and click **Next**.

![](Media/Module01/1-ggg.png)

11. You have now installed PowerShell Core on Windows 10. Note the installation path where the command prompt has started.

![](Media/Module01/1-hhh.png)

### Task 2. Install PowerShell Core on Windows Server Core

1. Switch to the Windows Server Core machine and enter the password **PowerShell6** to log in.
   
2. Windows Server Core has no GUI installed - the window that launches will be a command prompt. Type in **PowerShell** and press Enter to launch Windows PowerShell.

![](Media/Module01/1-iii.png)

3. Copy and paste the scriptblock below to create a new folder and download the PowerShell msi from the Github releases page. The script then installs the msi file.

```
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$uri = 'https://github.com/PowerShell/PowerShell/releases/download/v6.1.0/PowerShell-6.1.0-win-x64.msi'
$outFile = $uri.Split("/")[-1]
New-Item -Path C:\Temp -Type Directory
Invoke-WebRequest -Uri $uri -OutFile "C:\Temp\$outFile" -UseBasicParsing -Verbose
Set-Location C:\Temp
Start-Process -FilePath $outFile -ArgumentList "/qn" -Wait
exit
```

1. Change the location to C:\Program Files\PowerShell\6 at the command prompt.

```
cd "\Program Files\PowerShell\6"
```

5. Launch PowerShell Core by typing **pwsh** and pressing **Enter**.

![](Media/Module01/1-jjj.png)

6. You have now installed PowerShell Core in Windows Server Core.

### Task 3. Install PowerShell Core on Ubuntu

1. Switch to the Ubuntu virtual machine in the lab and enter the password **PowerShell6** 

2. First we will use the release from the Github page to install PowerShell Core.

3. Enter the commands below at the prompt and press **Enter** after each one. 

```
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
```
```
sudo curl -o /etc/apt/sources.list.d/microsoft.list https://packages.microsoft.com/config/ubuntu/16.04/prod.list
```
```
sudo apt-get update
```
```
sudo apt-get install -y powershell
```
4. When this completes - type **pwsh** to launch PowerShell. Note your installation version and path may be different from below.

![](Media/Module01/1-kkk.png)

5. Now that PowerShell is installed - let's use the Snapcraft snap to install it from the Ubuntu snap store. Enter the line below and press **Enter** to remove PowerShell.

```
sudo apt purge -y powershell
```

6. Now enter the line below and press **Enter** to install PowerShell from the Ubuntu snap store
   
```
sudo snap install powershell --classic
```

7. When this completes - type **pwsh** to launch PowerShell. Note your installation version and path may be different from below.

![](Media/Module01/1-kkk.png)


## Exercise 2: Verify Installed Version

#### Introduction  
Run some common commands on each operating system

#### Prerequisites (if applicable)
- PowerShell Core installed

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1. Verify PowerShell Versions

1. Switch to the Windows 10 machine and click on Start. Type **PowerShell** and launch Windows PowerShell.

2. Enter the code below and press **Enter**
   
```
$PSVersionTable
```

3. You should see that the version is 5.1 - this indicates Windows PowerShell is running.
   
```
Name                           Value
----                           -----
PSVersion                      5.1.17134.165
PSEdition                      Desktop
PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0...}
BuildVersion                   10.0.17134.165
CLRVersion                     4.0.30319.42000
WSManStackVersion              3.0
PSRemotingProtocolVersion      2.3
SerializationVersion           1.1.0.1
```

4. Enter the code below in Windows PowerShell and press **Enter**
```
Get-ChildItem Variable:\ | Where-Object Name -match "^Is"
```
5. There should be no output.
 
6. Now launch PowerShell Core from the start menu.
 
7. Enter the code below and press **Enter**
   
```
$PSVersionTable
```
8. You should see that the PSVersion is now 6.xxxxxxxx . Your version may be different.
```

Name                           Value
----                           -----
PSVersion                      6.1.0
PSEdition                      Core
GitCommitId                    6.1.0
OS                             Microsoft Windows 10.0.17134
Platform                       Win32NT
PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0...}
PSRemotingProtocolVersion      2.3
SerializationVersion           1.1.0.1
WSManStackVersion              3.0
```
9. Enter the code below in Windows PowerShell and press **Enter**
```
Get-ChildItem Variable:\ | Where-Object Name -match "^Is"
```
10. This time the output shows that the operating system is Windows and you are using the .NET Core Common Language Runtime. These new automatic variables exist only in PowerShell Core and can be used in scripts to determine the current OS. 
```
Name                           Value
----                           -----
IsCoreCLR                      True
IsLinux                        False
IsMacOS                        False
IsWindows                      True
```
11. Switch to the Ubuntu virtual machine and ensure PowerShell is launched by typing **pwsh** and pressing **Enter**. Your prompt should start with **PS**.

12. Enter the code below and press **Enter**
   
```
$PSVersionTable
```
13.  You should see that the PSVersion is 6.xxxxxxxx . Your version may be different.
```
Name                           Value
----                           -----
PSVersion                      6.1.0
PSEdition                      Core
GitCommitId                    6.1.0
OS                             Linux 4.15.0-1014-azure #14~16.04.1-Ubuntu SMP Thu Jun 14 15:42:55 UTC 2018
Platform                       Unix
PSCompatibleVersions           {1.0, 2.0, 3.0, 4.0...}
PSRemotingProtocolVersion      2.3
SerializationVersion           1.1.0.1
WSManStackVersion              3.0
```
14. Enter the code below in Windows PowerShell and press **Enter**
```
Get-ChildItem Variable:\ | Where-Object Name -match "^Is"
```
15. This time the automatic variable indicates your are using a Linux system.
```
Name                           Value
----                           -----
IsCoreCLR                      True
IsLinux                        True
IsMacOS                        False
IsWindows                      False
```

### Task 2. Run Common Commands

1. Switch to the Windows Server virtual machine. Ensure PowerShell Core is running by typing in **pwsh** and pressing **Enter**

2. Run the Get-Service command below and verify that a list of services are displayed. 
```
Get-Service
Get-Process
```
3. This is a relatively common command on a Windows system for retrieving the values of services and processes.

4. Switch the the Ubunutu virtual machine and run only the Get-Service command.
```
Get-Service
```
5. You should get an error similar to below. This is because the Linux system does not understand services in the same way that Windows does. 
```
Get-Service : The term 'Get-Service' is not recognized as the name of a cmdlet, function, script file, or operable program.
Check the spelling of the name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ Get-Service
+ ~~~~~~~~~~~
+ CategoryInfo          : ObjectNotFound: (Get-Service:String) [], CommandNotFoundException
+ FullyQualifiedErrorId : CommandNotFoundException
```
6. Run the Get-Process command as below.
```
Get-Process
```
7. This time you will get output - Get-Process is implemented.

8. Run the following command to view all the *Get* commands available on Linux. You will notice there are very few (48) compared to the Windows operating system. Where native cmdlets do not exist we still need to use some traditional Linux commands to manage the system although we can use some of the benefits of PowerShell's object orientated architecture to assist.

```
Get-Command -Verb Get | Where Source -ne PSDesiredStateConfiguration | Format-Wide -Autosize
(Get-Command -Verb Get | Where Source -ne PSDesiredStateConfiguration).Count
```

<!--
TODO: Another example may be required. 
-->




