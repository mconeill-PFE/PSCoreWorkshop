<!--
WorkshopPLUS - PowerShell Core
Module 09: Git
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Git Installation and Configuration

#### Introduction  
Install the Git Software and configure user defaults

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1: Installing Git

1. Switch to the Windows 10 VM and open a brower - navigate to https://git-scm.com/downloads

2. Click on the **Download 2.18.0 for Windows** button.

![](Media/Module07/7-aaa.png)

3. Click on **Run** when the download starts. 

![](Media/Module07/7-bbb.png)

4. Click **Next**

![](Media/Module07/7-ccc.png)

5. Leave the default location and click **Next**

![](Media/Module07/7-ddd.png)

6. Leave the default components checked and click **Next**

![](Media/Module07/7-eee.png)

7. Leave the default start menu settings and click **Next**

![](Media/Module07/7-fff.png)

8. Use the dropdown to choose an editor. By default VIM is selected although this may be difficult to use if you have no experiance with it. In the example below Nano is chosen because it is simple to use. Select an editor and click **Next**

![](Media/Module07/7-ggg.png)

9. Leave the default settings and click **Next**

![](Media/Module07/7-hhh.png)

10. Leave the default settings and click **Next**

![](Media/Module07/7-iii.png)

11. Leave the default settings and click **Next**. If you are editing files from a Linux machine on a Windows environment regularly you may want to choose the second option. 

![](Media/Module07/7-jjj.png)

12. Leave the default setting and click **Next**. 

![](Media/Module07/7-kkk.png)

13. Leave the default settings and click **Next**.

![](Media/Module07/7-lll.png)

14. Monitor the installation - it will take a couple of minutes to finish.

![](Media/Module07/7-mmm.png)

15. When complete uncheck the **View Release Notes** box and click **Finish**

![](Media/Module07/7-nnn.png)

### Task 2: Creating a Repository and First Commit - Command Line

1. Git is easy to learn from the command line interface and contains some actions which cannot be performed in Visual Studio Code which has native Git integration. Click Start and open the Git CMD program.

2. This is the Git command line interface - you can run any git command from here. Type in **git** and press enter to see a basic list of commands.

3. We must set a user name and email address for commit details. Type code below replacing your user name with your name and email address with an email address of your choosing.
```
git config --global user.name "your name here"
git config --global user.email "your email here"
```

4. Close the Git command line and open Windows PowerShell as an administrator. Run the line below to install a module to help visualise Git from the command line.
```
Install-Module posh-git -force
```
5. Close the window and reopen Windows PowerShell as a normal user. Set your location as C:\Labs\Module7.
```
Set-Location C:\Labs\Module07
```
6. To create a repository we use the **init** command, if a folder doesnt exist for the repository it will be created. At the command line type the code below and press **Enter**.
```
git init MyFirstRepo
```
7. You should get a result similar to the below.
```
Initialized empty Git repository in C:/Labs/Module07/MyFirstRepo/.git/
```
8. Change to the directory by using **cd MyFirstRepo** and type **Enable-GitColors** and press **Enter**. You should now see a prompt similar to the below.
```
C:\labs\Module07\MyFirstRepo [master]>
```
9. The name in square brackets indicates which branch you are currently in - **master** in this case. Let's create a file - add some content and work through the process to commit changes. Type the code below and press **Enter**.
```
New-Item myfile.txt | Set-Content -Value "This is some text"
```
10. The prompt will change when you create this file to the below.
```
C:\labs\Module07\MyFirstRepo [master +1 ~0 -0 !]>
```
11. The **+1** indicates there is one non-staged change in the branch. Type **git status** and press **Enter**.
```
C:\labs\Module07\MyFirstRepo [master +1 ~0 -0 !]> git status
On branch master

No commits yet

Untracked files:
  (use "git add <file>..." to include in what will be committed)

        myfile.txt

nothing added to commit but untracked files present (use "git add" to track)
```
12. The **status** command is used to view the current repository status. In this case it indicates
    - We are on the master branch
    - There are no commits
    - There is an untracked file
    - We should use git add to track this file.
As you use Git more often you will see it is very good at telling you what commands to run.

13. To add the file to the staging area we use the **git add** command. You can either specify the file(s) you want to add or use a period character to indicate everything. Run the code below to add the file to the staging are - and then display the status.
```
git add .
git status
```
14. Now the prompt has changed to a green **+1** to indicate we have one changed staged. It also tells use that
    - We are on branch master
    - There are no commits
    - One new file is ready to be committed.

```
C:\labs\Module07\MyFirstRepo [master +1 ~0 -0 !]> git add .
C:\labs\Module07\MyFirstRepo [master +1 ~0 -0 ~]> git status
On branch master

No commits yet

Changes to be committed:
  (use "git rm --cached <file>..." to unstage)

        new file:   myfile.txt
```

15. Commit the change by using the code below. The **-m** switch allows you to input a commit message. If you don't supply this in the command line the Nano editor will be launch for you to input a commit message.
```
git commit -m "My first commit"
```
16. You should get output similar to the below indicating the commit was successful.
```
C:\labs\Module07\MyFirstRepo [master]> git commit -m "My first commit"
[master bbe188a] My first commit
 1 file changed, 1 insertion(+)
 create mode 100644 myfile.txt
C:\labs\Module07\MyFirstRepo [master]>
``` 
17. You can view the commit history by using **git log**. Type it in and press **Enter**
```
C:\labs\Module07\MyFirstRepo [master]> git log
commit bbe188a36482574a09559a4568c2be15b8a9a632 (HEAD -> master)
Author: Contoso Student <student@CONTOSO.COM>
Date:   Tue Jul 31 01:02:05 2018 +0000

    My first commit
```
This show the following information
- The commit hash - this is used to identify a commit and will be the same globally.
- The author name and email address
- The date of the commit
- The commit message

18. Now try a commit without the **-m** parameter:
```
git commit
```

19. Now you are in an editor: 
```

# Please enter the commit message for your changes. Lines starting
# with '#' will be ignored, and an empty message aborts the commit.
#
# On branch master
# Your branch is up to date with 'origin/master'.
#
# Changes to be committed:
#       modified:   myfile.txt
#
~
~
~
~
C:/labs/module07/.git/COMMIT_EDITMSG [unix] (12:45 26/10/2018)  
  1,0-1 All"C:/labs/module07/.git/COMMIT_EDITMSG" [converted][unix] 10L, 261C
```

20. To exit, type in a message of the commit, something like 'This is the next commmit.'

21. Now the issue is, how do you exit? After you have typed in your message, hit the **ESC** button, and type **:wq** which will commit the edit to the file and close the editor.

22. To review you have used the following (porcelain) commands to create a repository and add a file and commit.

|Command | Function|
|--- | ---| 
|git init| Creates a blank repository|
|git add| Adds file to the staging area|
|git commit| Commits files to the repository|
|git stats| View the repository status|
|git log| View the repository history|

23. Add some more files and make some more commits - at least 3 - view the status and log as your history grows. You can use the command below to view a condensed version of the log.
```
git log --oneline
```
```
C:\labs\Module07\MyFirstRepo [master]> git log --oneline
1fad394 (HEAD -> master) added a script
b7e48b4 Another commit
bbe188a My first commit
```
### Task 3: Branching and Merging

1. Branches are used in Github to separate lines of development. By default each repository starts of with a branch called master. You can view the branches by running **git branch**.
```
C:\labs\Module07\MyFirstRepo [master]> git branch
* master
```
2. The asterisk indicates which branch is currently checked out. Create a new branch for development by running the code below.
```
git branch development
git checkout development
```
The prompt should update as below.
```
C:\labs\Module07\MyFirstRepo [master]> git branch development
C:\labs\Module07\MyFirstRepo [master]> git checkout development
Switched to branch 'development'
C:\labs\Module07\MyFirstRepo [development]>
```
3. Create some new files in this branch and make some commits by running the code below to automatically generate some information in the repository.
```
for ($i = 1; $i -lt 4; $i++)
{ 

    New-Item "file$i.txt"
  iex  "git add ."
  iex  "git commit -m 'Added file'"
    
}
```
4. Run the command below to examine the history of the repository. You should see where the master branch is pointing to and the new commits in the development branch.
```
git log --oneline
```
5. Switch back to the master branch and list the files in the directory. The 3 new files will not appear - working in a different branch has no effect on any other branches. 

6. Merging is the process of merging changes in one branch into another branch. Run the code below to merge the development branch into the master branch.
```
git checkout master
git merge development
```
You should get output similar to the below.
```
C:\labs\Module07\MyFirstRepo [master]> git merge development
Updating 1fad394..a220fca
Fast-forward
 file1.txt | 0
 file3.txt | 0
 2 files changed, 0 insertions(+), 0 deletions(-)
 create mode 100644 file1.txt
 create mode 100644 file3.txt
```
7. Check the history of the commits using git log. Git has merged your branch into the master branch and all the commits now appear in the master branch.

8. Run the code below to create another branch, add and commit some files, then perform a different type of merge.
```
iex "git checkout -b dev2"

for ($i = 1; $i -lt 4; $i++)
{ 

    New-Item "dev_2_$i.txt"
  iex  "git add ."
  iex  "git commit -m 'Added dev file'"
    
}

iex "git checkout master"
iex "git merge dev2 --no-ff"
```
9. Run the command below and examine how not using a fast forward merge has preserved the history of the **dev2** branch.
```
git log --oneline --graph
```
```
C:\labs\Module07\MyFirstRepo [master]> git log --oneline --graph
*   340ddf0 (HEAD -> master) Merge branch 'dev2'
|\
| * 384d719 (dev2) Added dev file
| * 503c313 Added dev file
| * 3241c85 Added dev file
|/
* a220fca (development) Added file
* 333f597 Added file
* b6251fa Added file
* b7b356b Added file
* c92170d Added file
* 1fad394 added a script
* b7e48b4 Another commit
* bbe188a My first commit
```
10. Delete the dev2 branch by running the code below.
```
git branch -d dev2
```

### Task 4: Git in Visual Studio Code

1. Open Visual Studio Code and press **Ctrl-K** - then **Ctrl-O** (Open a folder)

2. Navigate to C:\Labs\Module07\MyFirstRepo and click **Select Folder**.

3. Check the bottom right hand corner of the VS Code window - you should see the word *master*. This indicates that you are in a Git repository and your current branch is master. 

![](Media/Module07/7-ppp.png)

4. Create a new file in VS Code and type some text into it. **Ctrl-N** for new file, **Ctrl-S** to save. 

5. Git has detected you have a change to a file by displaying a one next to the source control icon. Click on the icon as indicated. 

![](Media/Module07/7-qqq.png)

6. Enter a commit message and click the tick mark as indicated.

![](Media/Module07/7-rrr.png)

7. Visual Studio Code will prompt you to stage changes - this is the same as running **git add .**. Click **Always**

![](Media/Module07/7-sss.png)

8. The change has been committed. 

9.  Open one of the text files that has some text in it - there is nothing in that file apart from the text.

![](Media/Module07/7-ttt.png)

10. Install the GitLens extension through the Extensions button and click Reload once it is done. If you need help installing extensions refer to Module 2.

11. Now go back to the file with text and look at how it is displayed. Hover over the grey text showing the author of the line. Git displays all the information about that line in the pop out box. Click on the three dots at the bottom of the box and view some of the options available.

![](Media/Module07/7-uuu.png)

![](Media/Module07/7-vvv.png)

12. Add another line of text to the file and save it - **Ctrl-S**.

13. Click on the Source Control icon in VS Code and you can see the file listed as being modified. Click on the file. Note how a copy opens up which shows all the changes between the new and old version. Add a comment and commit the file.

![](Media/Module07/7-www.png)

14. The Git extension in VS Code allows you to perform many actions. Make a couple more changes to files and commit them. Check out the GitLens icon which is added to VS Code for a more interactive way to view your repository and its history.

![](Media/Module07/7-yyy.png)

## Exercise 2: Using Git Online - Github

#### Introduction  
Create a Github account and sync your repository

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

### Task 1: Create a Github Account

#### Note: If you have an existing Github account you can skip this task and log in to your existing account.

1. Navigate to www.github.com

2. Enter a user name, password and email address to create a free account.

![](Media/Module07/7-zzz.png)

3. You can complete the questions in there or select **Skip this Step**

4. Once complete you will be logged in - you will have to check the email address you used to sign up and complete the verification process.  

### Task 2: Create a Repository and Push

1. In the Github page - click on **New Repository**.

![](Media/Module07/7-baa.png)
   
2. Enter **MyFirstRepo** for the name and click on **Create Repository**

![](Media/Module07/7-caa.png)

3. Github tells you how to push your code to the new online repository - click the copy button in the section highlighted and paste it into your PowerShell window and run it. You should get output similar to that below the image.

![](Media/Module07/7-daa.png)

```
C:\labs\Module07\MyFirstRepo [master]> git remote add origin https://github.com/JoeBBloggs/MyFirstRepo.git
C:\labs\Module07\MyFirstRepo [master]> git push -u origin master
Enumerating objects: 30, done.
Counting objects: 100% (30/30), done.
Delta compression using up to 2 threads.
Compressing objects: 100% (24/24), done.
Writing objects: 100% (30/30), 2.50 KiB | 320.00 KiB/s, done.
Total 30 (delta 13), reused 0 (delta 0)
remote: Resolving deltas: 100% (13/13), done.
To https://github.com/JoeBBloggs/MyFirstRepo.git
 * [new branch]      master -> master
Branch 'master' set up to track remote branch 'master' from 'origin'.
C:\labs\Module07\MyFirstRepo [master ≡]>
```
The lines above perform the following actions.
- Add a remote location to your repository. The default remote location is called origin.
- Push your master branch to origin - it will create a branch called master
- Compress and send your code to Github 
- Your PowerShell prompt has now changed to show a hamburger after the master branch - this indicates that you are up to date with the remote location. 

4. In the Github window click on the **Code** button. You should see your files.

![](Media/Module07/7-eaa.png)

5. Create a new file in VS Code and commit it. You should see the icons down at the base of the window change to indicate you have a change pending to be pushed to the remote location. Click on the icon and Git will sync with the remote location - pushing your changes.

![](Media/Module07/7-faa.png)

### Task 3: Pull From Your Repository

1. Changes can be made to files in your repository by other people - either in the Github pages or their local installation of Git. These changes are then pushed to online. Before you can commit any new changes - Git will ensure you have the latest copy of files by performing a pull.

2. In the Github window - click on a file and click the Edit icon.

![](Media/Module07/7-gaa.png)

3. Add some text into the window and then scroll down to the commit area. Update the commit text and select commit. 

![](Media/Module07/7-haa.png)

4. VS Code periodically tells Git to perform a fetch operation which looks for changes in remote branches. This is reflected in the status bar at the bottom window of the VS Code program.

![](Media/Module07/7-iaa.png)

5. Click on the circular icon and changes from the remote branch will be synced to your local copy.

### Task 4: Pull Request

1. A pull request is a formal declaration that you want to merge code into a branch. It can trigger build processes, reviews and approvals. This action cannot be performed from the command line or Visual Studio Code. 

2. In the Github window - select and edit another file. This time instead of clicking on Commit Changes - check the button marked "*Create a new branch and start a pull request*". 

![](Media/Module07/7-jaa.png)

3. In the new window you can change the pull request title and add reviewers and labels. It will also show you what changes are going to be made when the change is merged. Click on **Create Pull Request**

![](Media/Module07/7-kaa.png)

4. Github will automatically check to see if any conflicts would occur by merging. If everything is ok it will allow you to complete the merge process. Click on **Merge Pull Request** and then **Confirm Merge** to complete.

![](Media/Module07/7-laa.png)

5. When complete the changes will be part of the repository and you can now delete the branch.

### Task 5: Fixing Common Mistakes

#### Merge Conflicts

1. Git will not let you overwrite code or make a change in a merge that will affect other work. Run the code below to set up a new repository, create files and force a merge conflict to occur. 
```
Set-Location C:\Labs\Module07
.\MergeConflict.ps1
```

2. You should get a merge conflict as indicated below.
```
C:\Labs\Module07\MergeConflict [master +0 ~1 -0 !]> git add . ; git commit -m 'Modified file in master' ; git merge conf
lictbranch
[master 9d63b6c] Modified file in master
 1 file changed, 1 insertion(+), 1 deletion(-)
Auto-merging file1.txt
CONFLICT (content): Merge conflict in file1.txt
Automatic merge failed; fix conflicts and then commit the result.
```
3. Open the file1.txt file in **Notepad** and examine it.
```
<<<<<<< HEAD
changing the text in the file in the master branch
=======
adding some text to the file
changing the text in the file in the conflict branch
>>>>>>> conflictbranch
```
4. Git has put markers into the file to show what has changed and where the change was made. The **=======** acts as a delimeter between the changes. Text above this line is from the current change and text below is from the incoming change. This is indicated by the less than and greater than symbols and the branch names are marked. **HEAD** refers to the current branch - it may be master or it may be another branch - it is the current checked out location. 

5. Now open file1.txt in Visual Studio Code and observe the results. As well as the Github tags - VS Code provides buttons to accept either the current or incoming change. 

![](Media/Module07/7-maa.png)

6. To resolve the conflict click on **Accept Incoming Change** and save the file.

7. Use the process we have learned to add the changed file to the staging area and commit it.

#### Working in the Wrong Branch

1. It's very easy to start working on some code and then realise you have been working in the wrong branch the whole time. This process helps you switch to the correct branch without losing any work.

2. Run the code below to set up the scenario.
```
Set-Location C:\Labs\Module07
.\WrongBranch.ps1
```
3. This time an error occurs stating that if I try and switch branches my changes will not be saved.
```
error: Your local changes to the following files would be overwritten by checkout:
        file1.txt
Please commit your changes or stash them before you switch branches.
Aborting
```
4. Git tells us what to do - we use the **git stash** command to stash our changes away - and then switch to the new branch and apply those changes. Run the code below - typing each line and pressing **Enter** so you can see the changes occur. 
```
git stash
git checkout dev
git stash apply
```
5. You will get a merge conflict as Git will not allow you to overwrite the files with the stash. Use what you learned in the last task to fixz the conflict so your changes are not overwritten. 
```
<<<<<<< Updated upstream
This is for the dev branch
=======
This is for the master branch
This is meant to be for the dev branch
>>>>>>> Stashed changes
```

#### Modifying a Commit

1. This time you have committed some files but forgotten a very quick change. You can amend a commit by using the amend switch. Amend the previous commit you made by running the code below.
```
git commit --amend
```

#### Restoring a File

1. Restoring a file from a previous version is not difficult. You can use GitLens in CS Code or the gitk utility to find the correct version of the file. Once you have done this you need to checkout the file - and then commit the changes. 

2. Run the code below to set up the scenario.
```
Set-Location C:\Labs\Module07
.\RestoreFile.ps1
```
3. Open the folder in Visual Studio Code - **Ctrl-K** **Ctrl-O**

4. Click on the GitLens icon and drill down in the file history and select a file to restore. 

![](Media/Module07/7-naa.png)

5. The left pane shows the file prior to the commit - the right side shows after the commit. If you want to restore the file to the version on the right hand side, right click on the file and select **Apply Changes**

6. This will restore the file and stage it. Use what you have learned to commit the changed file. 

