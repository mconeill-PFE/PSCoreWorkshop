# Module 1

## Exercise 1
Sign in to DC
Install PowerShell Core from CLI
Launch PowerShell (this should be server core so no ISE)

Sign in to WS
Install PowerShell Core
Launch PowerShell 

Sign in to Ubuntu
Install and launch PowerShell Core
- download and install using dpkg
- install using snap

## Exercise 2
Verify $PSVersionTable on each machine

Verify .NET Version on each machine

Run Get-Service on each machine - why does Ubuntu fail

Run Get-Process on each machine

Look at available commands on Ubuntu

Run systemctl or any other sudo command and watch it fail :( 

Launch sudo pwsh

# Module 2

## Exercise 1

Install Visual Studio Code on WS manually from download

Install PowerShell extension and others

Uninstall and reinstall from the vscode script with extension
- Common settings

## Exercise 2

Open demo script folder
- Script creation
- Script search / find/replace
- Running Scripts
- Debugging environment
- Pester Tests
- Markdown / JSON files

# Module 3

# Module 4

Demonstrate using grep, sed, awk, using Select-String, Replace, Foreach?? and Write-Output or calculated fields

How it works with objects as opposed to text

File paths and case sensitivity

File editing nano,vim

# Module 5 - Remoting

## Exercise 1

PowerShell remoting with 5.1 across WS to DC

PowerShell remoting with Core from WS to DC

## Exercise 2

OpenSSH Setup on Windows and SSHD config

SSH keys

Remoting from Windows to Ubuntu

Remoting from Ubuntu to Windows

# Module 6 - DSC

## Exercise 1

Develop DSC configuration for Windows and Linux - push configuration - web server configuration using IIS and Apache2

## Exercise 2

Install omi and dsc on Linux

# Module 7 - Git

Create repo add files, commit

Branching

Merging and rebase

Push / pull (user can create or use Github account) - push from Windows pull to Linux??

Pull requests

Fixing common mistakes
- reset --hard
- commit in wrong branch
- amend
- working in wrong branch

# Module 8 - Azure

Installing Azure modules on WS and Ubuntu

Azure Cloud Shell



