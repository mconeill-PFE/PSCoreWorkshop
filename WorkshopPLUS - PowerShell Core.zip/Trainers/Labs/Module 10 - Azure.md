<!--
WorkshopPLUS - PowerShell Core
Module 10: Azure
-->

#### Note: Unless explicitly advised the use of PowerShell refers to **PowerShell Core**. If Windows PowerShell is to be used the instruction will state **Windows Powershell**.

## Exercise 1: Install Azure Modules

#### Introduction  
Install Azure Module for Windows PowerShell and PowerShell Core

#### Prerequisites (if applicable)   

#### Estimated Time to Complete This Lab  
20 minutes

## Exercise 2: Use Azure Cloud Shell